function startSite(){
document.querySelector(".overlay").style.display="none";
document.querySelector(".container").classList.remove("hidden");
animate();
}

const canvas=document.getElementById("hearts");
const ctx=canvas.getContext("2d");
canvas.width=window.innerWidth;
canvas.height=window.innerHeight;

let hearts=[];

function createHeart(){
hearts.push({x:Math.random()*canvas.width,y:canvas.height,size:10+Math.random()*10,speed:1+Math.random()*2});
}

function drawHeart(x,y,s){
ctx.fillStyle="pink";
ctx.beginPath();
ctx.moveTo(x,y);
ctx.bezierCurveTo(x-s,y-s,x-2*s,y+s,x,y+2*s);
ctx.bezierCurveTo(x+2*s,y+s,x+s,y-s,x,y);
ctx.fill();
}

function animate(){
ctx.clearRect(0,0,canvas.width,canvas.height);
if(Math.random()<0.3) createHeart();
hearts.forEach(h=>{h.y-=h.speed;drawHeart(h.x,h.y,h.size);});
requestAnimationFrame(animate);
}
